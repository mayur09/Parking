<?php 
 $page_type = 'about';

	require("header.php"); // Will include nav.php and inc_styles.php

?>
	
	<section id="content">
					
		<div class="container">
			
			<div class="page-header clearfix">

				<h1>About us</h1>

			</div><!--/ .page-header-->

			<h4 class="content-title">What is GujjuColleges?</h4>

			<div class="sixteen columns row">

				<p>
					We are a group of individuals committed to providing best quality information to the students seeking to step into professional colleges for higher education.
					</p>
					</br>

<p>Being from Engineering colleges from Gujarat, we discovered a big gap in qualititive information to help them decide on selecting the college available. With the increase in number of colleges , the complexity had increased and there is even more intense need to find a solution to address the college selection dilemma.</p>

</br>

</p>Our goal is to provide relevant, accurate information of colleges in  a very user friendly manner so as to make the optimum use of it. We constantly endeavor to stretch ourselves to improve ourselves and would welcome any suggestions.
				</p>	

			</div>
			
			

			

			



			<div class="clear"></div>
			<div class="divider-solid"></div>

			<div class="clear"></div>
			<div class="white-space"></div>

		</div><!--/ .container-->
	 
	</section><!--/ #content-->
    

<?php 

include('footer.php');

?>