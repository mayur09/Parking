<?php

?>

<section id="content">
					
		<div class="container">
			
			
			<div class="page-header clearfix">

				<h1>Compare Colleges</h1>

			</div><!--/ .page-header-->



				<div class="four columns label compare">

				
				<h3>Parameters</h3>
		
				<h5>	
					<ul>
						<li id="logo">Logo</li>
						<li>Name</li>
						<li>Category</li>
						<li>AICTE</li>
						<!-- <li>Courses</li> -->
						<li>Fees</li>
						<li>Contact Phone</li>
						<li>Email</li>
						<li>Website</li>
					</ul>


				</h5>
			</div><!--/ .columns-->

			<div class="four columns label compare">

				
				<h3><?php echo $name1;?></h3>

				<h6>
					<ul>
						<li style="margin:0px 0px 10px 0px;"><img src="./images/logos/<?php echo $logo1;?>"></li>
						<li style="margin:0px 0px 10px 0px;"><?php echo $name1;?></li>
						<li style="margin:0px 0px 10px 0px;"><?php echo $ctgry1;?></li>
						<li style="margin:0px 0px 10px 0px;"><?php echo $aicte1;?></li>
						<li style="margin:0px 0px 10px 0px;"><?php echo $fees1;?></li>
						<li style="margin:0px 0px 10px 0px;"><?php echo $phone1;?></li>
						<li style="margin:0px 0px 10px 0px;"><?php echo $email1;?></li>
						<li style="margin:0px 0px 10px 0px;"><?php echo $web1;?></li>
					</ul>

				</h6>

			</div><!--/ .columns-->

			<div class="four columns label compare">

				
				<h3><?php echo $name2;?></h3>
				
				<h6>
					<ul>
						<li style="margin:0px 0px 10px 0px;"><img src="./images/logos/<?php echo $logo2;?>"></li>
						<li style="margin:0px 0px 10px 0px;"><?php echo $name2;?></li>
						<li style="margin:0px 0px 10px 0px;"><?php echo $ctgry2;?></li>
						<li style="margin:0px 0px 10px 0px;"><?php echo $aicte2;?></li>
						<li style="margin:0px 0px 10px 0px;"><?php echo $fees2;?></li>
						<li style="margin:0px 0px 10px 0px;"><?php echo $phone2;?></li>
						<li style="margin:0px 0px 10px 0px;"><?php echo $email2;?></li>
						<li style="margin:0px 0px 10px 0px;"><?php echo $web2;?></li>
					</ul>

				</h6>


			</div><!--/ .columns-->

		</div>
	</section>
