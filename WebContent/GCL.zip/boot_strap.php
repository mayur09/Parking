
<?php

?>


<link href="//netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css" rel="stylesheet">
<script src="http://code.jquery.com/jquery-2.0.3.min.js"></script> 
<script src="//netdna.bootstrapcdn.com/bootstrap/3.0.0/js/bootstrap.min.js"></script>



<link href="./bootstrap-editable/css/bootstrap-editable.css" rel="stylesheet">
<script src="./bootstrap-editable/js/bootstrap-editable.js"></script>
