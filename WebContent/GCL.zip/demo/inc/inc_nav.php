<?php ?>

			<div class="sixteen columns">
				
				<div class="menu-container clearfix">

					<nav id="navigation" class="navigation">

						<div class="menu">
							<ul>
								<li><a href="index.php">Home</a>
<!-- 									<ul>
										<li class="current-menu-item"><a href="index.html">Home Page 1</a></li>
										<li><a href="index-2.html">Home Page 2</a></li>
										<li><a href="index-3.html">Home Page 3</a></li>
									</ul> -->
								</li>
								<li><a href="compare.php">Compare Colleges</a>

									<!-- <ul>
										<li><a href="portfolio-2-columns-sidebar.html">With Sidebar</a>
											<ul>
												<li><a href="portfolio-2-columns-sidebar.html">Portfolio 2 Columns</a></li>
												<li><a href="portfolio-3-columns-sidebar.html">Portfolio 3 Columns</a></li>
												<li><a href="portfolio-4-columns-sidebar.html">Portfolio 4 Columns</a></li>
												<li><a href="portfolio-single-sidebar.html">Portfolio Single</a></li>
											</ul>
										</li>
										<li><a href="portfolio-2-columns.html">Without Sidebar</a>
											<ul>
												<li><a href="portfolio-2-columns.html">Portfolio 2 Columns</a></li>
												<li><a href="portfolio-3-columns.html">Portfolio 3 Columns</a></li>
												<li><a href="portfolio-4-columns.html">Portfolio 4 Columns</a></li>
												<li><a href="portfolio-single.html">Portfolio Single</a></li>
											</ul>
										</li>
									</ul> -->

								</li>
								<li><a href="recommend.php">Find best suits</a>


									<!-- <ul>
										<li><a href="left-nav.html">Left Navigation</a></li>
										<li><a href="about-us.html">About Us</a></li>
										<li><a href="services.html">Services</a></li>
										<li><a href="faq.html">FAQ</a></li>
										<li><a href="404.html">404 Page</a></li>
									</ul> -->


								</li>
								<li><a href="#">Features</a>
<!-- 									<ul>
										<li><a href="typography.html">Typography</a></li>
									</ul> -->
								</li>
								<!--<li><a href="#">Blog</a>

									 <ul>
										<li><a href="blog-single.html">Blog Single</a></li>
									</ul>
								</li>
								<li><a href="columns.html">Shortcodes</a> 
									<ul>
										<li><a href="elements.html">Elements</a></li>
										<li><a href="pricing-tables.html">Pricing Tables</a></li>
										<li><a href="columns.html">Columns</a></li>
										<li><a href="icons.html">Icons</a></li>
									</ul> -->


								</li>
								<li><a href="about-us.php">About</a></li>
								<li><a href="contactus.php">Contact</a></li>
							</ul>
						</div>

					</nav><!--/ .navigation-->
					
					<div class="search-wrapper">

						<form method="post" action="/">

							<p>
								<input name="s" id="s" type="text">
								<button type="submit" class="submit-search">Search</button>
							</p>

						</form>

					</div><!--/ .search-wrapper--> 		

				</div><!--/ .menu-container-->	
				
			</div><!--/ .columns-->