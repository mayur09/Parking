<?php
session_start();

echo $_SEESION['a'];
//echo $_SESSION['name'];
//echo $_SESSION['value'];

?>