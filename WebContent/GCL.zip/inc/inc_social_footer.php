<?php ?>
			<div class="eight columns">
				
				<div class="widget widget_contacts">

					
		
					<div class="clear"></div>
					
					<ul class="social-icons">
						<li class="twitter"><a href="https://twitter.com/GujjuColleges">Twitter</a></li>
						<li class="facebook"><a href="https://www.facebook.com/pages/GujjuColleges/174451579406029">Facebook</a></li>
						<li class="rss"><a href="#">Rss</a></li>
					</ul><!--/ .social-icons -->	
		
				</div>
					
			</div><!--/ .columns-->