<?php ?>



<div class="slider">
		
		<div id="layerslider-container">

			<div id="layerslider" style="width: 100%; height: 400px;">

				<div class="ls-layer" style="slidedirection: top; slidedelay: 8500;">

					<img class="ls-s2" style="top: 0; left: 0; durationin: 0; durationout: 0;" src="images/sliders/layerslider/haze.png">

					<img class="ls-s2" style="top: 20px; left: 135px; durationin : 1400; durationout: 800; slidedirection: right; slideoutdirection : left; easingin : easeOutExpo;"  src="images/sliders/layerslider/cloud_1.png">
					<img class="ls-s5" style="top: 20px; left: 480px; durationin : 1400; durationout: 800; slidedirection: right; slideoutdirection : left; easingin : easeOutExpo;"  src="images/sliders/layerslider/cloud_2.png">

					<h1 class="ls-s1 inline-h1" style="top: 189px; left: 38px; slidedirection: left; slideoutdirection: bottom; durationin: 1500; durationout: 400; delayin: 1000; easingin : easeOutExpo;">Guess your target.</h1>

					<h2 class="ls-s2 inline-h2" style="top: 250px; left: 38px; slidedirection: bottom; slideoutdirection: bottom; durationin: 1500; durationout: 400; delayin: 700; easingin : easeOutExpo;">
						Just by adding 
					</h2>
					<h2 class="ls-s3 inline-h2" style="top: 283px; left: 38px; slidedirection: bottom; slideoutdirection: bottom; durationin: 1500; durationout: 400; delayin: 1000; easingin : easeOutExpo;"> 
						fields and cities of your choice.
					</h2>

					<img class="ls-s4" style="top: 28px; left: 600px; durationin : 690; durationout: 1000; slidedirection: right; slideoutdirection : left; delayin : 500; easingin : easeOutExpo;" src="images/sliders/layerslider/plane_2.png">
					<img class="ls-s4" style="top: 102px; left: 350px; durationin : 900; durationout: 700; slidedirection: right; slideoutdirection : left; delayin : 300; easingin : easeOutExpo;" src="images/sliders/layerslider/plane_1.png">

				</div><!--/ .ls-layer-->

				<div class="ls-layer" style="slidedirection: bottom; slidedelay: 8500;">

					<img class="ls-s3" style="top: 47px; left: 38px; durationin : 1000; durationout: 800;" src="images/sliders/layerslider/pc.png">
					<img class="ls-s3" style="top: 150px; left: 250px; durationin : 1500; durationout: 800; slidedirection: top; slideoutdirection: bottom; easingin: easeOutExpo;" src="images/sliders/layerslider/logo.png">
					<!-- <img class="ls-s5" style="top: 151px; left: 415px; durationin : 1600;durationout: 800; slidedirection: top; slideoutdirection: bottom; delayin: 400;  easingin : easeInOutBounce;" src="images/sliders/layerslider/x.png"> -->

					<h1 class="ls-s1 inline-h1" style="top: 220px; left: 618px; durationin: 1500; durationout: 1200; slidedirection: right; slideoutdirection: bottom; easingin : easeOutExpo; delayin : 2500;">Just with few clicks</h1>

					<!-- <h3 class="ls-s5 inline-h3" style="top: 204px; left: 215px; durationin: 1500; slidedirection: bottom; slideoutdirection: bottom; easingin : easeOutExpo;">Tagline will go here</h3> -->

					<h2 class="ls-s6 inline-h2" style="top: 174px; left: 618px; durationout: 800; slidedirection: top; slideoutdirection: bottom; durationin : 1000; easingin : easeOutExpo; delayin : 1850;">Your choice better</h2>
					<h2 class="ls-s6 inline-h2" style="top: 141px; left: 618px;  durationout: 800;slidedirection: top; slideoutdirection: bottom; durationin : 1300; easingin : easeOutExpo; delayin : 1850;">Here is Everything to Make </h2>

				</div><!--/ .ls-layer-->

				<div class="ls-layer" style="slidedirection: top; slidedelay: 8500;">

					<h2 class="ls-s3 inline-other-h2" style="top: 112px; left: 28px; durationin : 1500; slidedirection: top; slideoutdirection : top; delayin : 1100; ">Access GujjuCollegs from</h2>
					<h1 class="ls-s3 inline-h1" style="top: 140px; left: 28px; durationin : 1500; slidedirection: top; slideoutdirection : top; delayin : 800; ">Different Devices</h1>

					<h2 class="ls-s2 inline-h2" style="top: 210px; left: 28px; slidedirection: bottom; slideoutdirection : bottom; durationin : 1500; durationout : 700; delayin : 1200;  easingin : easeOutExpo;">With Ease,</h2>
					<h2 class="ls-s3 inline-h2" style="top: 243px; left: 28px; slidedirection: bottom; slideoutdirection : bottom; durationin : 1100; durationout : 1100; delayin : 1500; easingin : easeOutExpo;">Grace</h2>
					<h2 class="ls-s4 inline-h2" style="top: 276px; left: 28px; slidedirection: bottom; slideoutdirection : bottom; durationin : 700; durationout : 700; delayin :  1800;  easingin : easeOutExpo;">and speed.</h2>

					<img class="ls-s4" style="top: 95px; left: 430px; durationin : 1500; durationout: 1000; slidedirection : left; slideoutdirection : left; " src="images/sliders/layerslider/device_horizontal.png">
					<img class="ls-s4" style="top: 25px; left: 630px; durationin : 1500; durationout: 1000; slidedirection : right; slideoutdirection : right; " src="images/sliders/layerslider/device_vertical.png">

				</div><!--/ .ls-layer-->
				
<!-- 				<div class="ls-layer" style="slidedirection: left; slidedelay: 8500; durationin: 1500; durationout: 1500; easingin: easeInOutQuint; easingout: easeInOutQuint; delayin: 0; delayout: 0;">
					
					<img class="ls-s3" src="images/sliders/layerslider/frame.png" style="top: 35px; left: 30px; slidedirection : left; slideoutdirection : left;  durationin : 1500; durationout : 1500; easingin : easeInOutQuint; easingout : easeInOutQuint; delayin : 0; delayout : 0;">
					
					<div  class="ls-s3" style="top:78px; left: 130px; slidedirection : left; slideoutdirection : left; durationin : 1500; durationout : 1500; easingin : easeInOutQuint; easingout : easeInOutQuint; delayin : 0; delayout : 0;">
						<div class="video-holder">
							<iframe src="http://player.vimeo.com/video/10112073" width="318" height="228" frameborder="0" webkitAllowFullScreen mozallowfullscreen allowFullScreen></iframe>
						</div>
					</div>
					
					<h2 class="ls-s3 inline-h2" style="top: 125px; left: 585px; slidedirection: top; slideoutdirection: right; durationin: 1500; durationout: 800; easingin : easeOutExpo; easingout : easeInOutQuint; delayin : 800;">You Can Read new updates</h2>		
					<h2 class="ls-s3 inline-h2" style="top: 160px; left: 585px; slidedirection: top; slideoutdirection: right; durationin: 1400; durationout: 800;  easingin : easeOutExpo; easingout : easeInOutQuint; delayin : 500; delayout : 150;">in academic niche</h2>		
					
					<h1 class="ls-s3 inline-h1" style="top: 216px; left: 585px; slidedirection: bottom; slideoutdirection: right; durationin: 1500; durationout: 1500; easinging: easeInOutQuint; easingout : easeInOutQuint; delayin : 0; delayout : 0;">Right over here!</h1> -->
					
				</div><!--/ .ls-layer-->

			</div><!--/ #layerslider-->

		</div><!--/ #layerslider-container-->
				
	</div><!--/ .slider-->