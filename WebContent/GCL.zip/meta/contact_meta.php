<?php ?>

<title>GujjuCollegs | Contact</title>	
	
	<meta name="description" content="A place where you can get all the information about colleges in Gujarat.">
	<meta name="author" content="GujjuColleges">