<?php ?>

<title>Compare Colleges</title>	
	
	<meta name="description" content="Compare Collegs according to fees, facilities, seats etc">
	<meta name="author" content="GujjuColleges">